//Program 3: Create arrays A, B and C of size 3 and perform C = A + B

#include<stdio.h>
#include<conio.h>

void main()
{
    int A[3], B[3], C[3];
    int i;

    printf("Enter 3 elements for Array A:\n");
    for(i=0; i<3; i++)
    {
        scanf("%d", &A[i]);
    }

    printf("\nEnter 3 elements for Array B:\n");
    for(i=0; i<3; i++)
    {
        scanf("%d", &B[i]);
    }

    for(i=0; i<3; i++)
    {
        C[i] = A[i] + B[i];
    }

    printf("\nArray C (A + B):\n");
    for(i=0; i<3; i++)
    {
        printf("%d ", C[i]);
    }

    getch();
}
