// WAP to perform insert,delete,display operation in simple queue
#include <stdio.h>
#define MAX 5   // Maximum size of queue

int queue[MAX];
int front = -1;
int rear = -1;

// Function to insert (enqueue)
void insert(int value)
{
    if (rear == MAX - 1)
    {
	printf("Queue Overflow! Cannot insert %d\n", value);
    } else
    {
	if (front == -1) front = 0;  // First element
	rear++;
	queue[rear] = value;
	printf("%d inserted into queue.\n", value);
    }
}

// Function to delete (dequeue)
void delete()
{
    if (front == -1 || front > rear)
    {
	printf("Queue Underflow! No element to delete.\n");
    }
    else
    {
	printf("%d deleted from queue.\n", queue[front]);
	front++;
    }
}

// Function to display queue
void display()
{
    if (front == -1 || front > rear)
    {
	printf("Queue is empty.\n");
    } else
    {
	int i;
	printf("Queue elements are: ");
	for ( i = front; i <= rear; i++)
	 {
	    printf("%d ", queue[i]);
	}
	printf("\n");
    }
}

// Main function
int main()
 {
    int choice, value;

    while (1)
    {
	printf("\nQueue Operations Menu:\n");
	printf("1. Insert\n");
	printf("2. Delete\n");
	printf("3. Display\n");
	printf("4. Exit\n");
	printf("Enter your choice: ");
	scanf("%d", &choice);

	switch (choice)
	{
	    case 1:
		printf("Enter value to insert: ");
		scanf("%d", &value);
		insert(value);
		break;
	    case 2:
		delete();
		break;
	    case 3:
		display();
		break;
	    case 4:
		printf("Exiting program.\n");
		return 0;
	    default:
		printf("Invalid choice! Please try again.\n");
	}
    }
}
